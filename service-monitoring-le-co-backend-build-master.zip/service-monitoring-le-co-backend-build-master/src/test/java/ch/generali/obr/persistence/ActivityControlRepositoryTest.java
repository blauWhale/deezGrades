package ch.generali.obr.persistence;

import ch.generali.obr.model.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.sql.Date;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
public class ActivityControlRepositoryTest {

    @Autowired
    private ActivityControlRepository activityControlRepository;

    private static ActivityControl activityControl;

    Outsourcing outsourcing = Outsourcing.builder()
            .outsourcer(Outsourcer.builder()
                        .name("Avanti")
                        .thirdPartyCheck(1)
                        .website("avanti.com")
                        .contactPerson("test")
                        .address(Address.builder()
                                .zipcode("8000")
                                .city("Zurich")
                                .street("Bahnhofstrasse 40")
                                .country("Switzerland")
                                .build())
            .build())
            .name("Cloud storage solution")
                .beginDate(Date.valueOf("2022-02-02"))
            .endDate(Date.valueOf("2023-02-02"))
            .cloudOutsourcingCheck(true)
                .outg_id(null)
                .nonOutsourcing(false)
                .independent(true)
                .vulnerability(false)
            .qualitativeMateriality(false)
            .contractCategory(2)
                .build();


    @Test
    void shouldSaveOutsourcing(){
        activityControl = ActivityControl.builder()
                .kpi("2")
                .contractReference("2000")
                .kpiControlActivity("do something")
                .evidence("here is what I did")
                .evidenceStorage("here is what I did")
                .riskDescription("a risk")
                .riskMitigation("a mitigation")
                .riskMitigationDate(Date.valueOf("2022-02-02"))
                .riskMitigationDeadline(Date.valueOf("2023-02-02"))
                .riskComment("a comment about the risk")
                .activity(Activity.builder()
                        .activity(1)
                        .description("legal advice")
                        .outsourcing(outsourcing)
                        .build())
                .report(Report.builder()
                        .name("Q1 Report")
                        .date(Date.valueOf("2022-02-02"))
                        .approveBy("Raphael Blaauw")
                        .approveDate(Date.valueOf("2022-02-12"))
                        .outsourcing(outsourcing)
                        .build())
                .build();

        ActivityControl savedActivityControl = activityControlRepository.save(activityControl);
        assertThat(savedActivityControl).usingRecursiveComparison().ignoringFields("id").isEqualTo(activityControl);
    }
}
