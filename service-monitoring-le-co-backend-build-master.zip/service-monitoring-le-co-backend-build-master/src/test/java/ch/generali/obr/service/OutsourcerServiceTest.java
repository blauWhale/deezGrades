package ch.generali.obr.service;

import ch.generali.obr.ObrServiceTestConfig;
import ch.generali.obr.model.Address;
import ch.generali.obr.model.Outsourcer;
import ch.generali.obr.persistence.AddressRepository;
import ch.generali.obr.persistence.OutsourcerRepository;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Objects;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = ObrServiceTestConfig.class)
public class OutsourcerServiceTest {

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private OutsourcerRepository outsourcerRepository;

    private static Outsourcer outsourcer;

    @BeforeEach
    void setUp() {
        outsourcer = Outsourcer.builder()
                .id(1)
                .name("Avanti")
                .thirdPartyCheck(1)
                .website("avanti.com")
                .contactPerson("test")
                .address(Address.builder()
                        .id(1)
                        .zipcode("8000")
                        .city("Zurich")
                        .street("Bahnhofstrasse 40")
                        .country("Switzerland")
                        .build())
                .build();
    }

    @Test
    public ResponseEntity<Outsourcer> createOutsourcer(){
        ResponseEntity<Outsourcer> httpEntity = rest.postForEntity("api/outsourcer", outsourcer, Outsourcer.class);
        Assertions.assertEquals(200, httpEntity.getStatusCodeValue());
        return ResponseEntity.ok(httpEntity.getBody());
    }

    @Test
    void lookupOutsourcerAvailable() {
        int id =  Objects.requireNonNull(createOutsourcer().getBody()).getId();
        ResponseEntity<Outsourcer> httpEntity = rest.getForEntity("api/outsourcer/" + id, Outsourcer.class );
        Assertions.assertEquals(200, httpEntity.getStatusCodeValue());
    }

    @Test
    void shouldUpdateOutsourcerById() {
        createOutsourcer();
        Outsourcer outsourcerAfter = Outsourcer.builder()
                .name("Google")
                .website("Google.com")
                .contactPerson("test2")
                .address(Address.builder()
                        .city("San Francisco")
                        .street("Street 123")
                        .zipcode("1825")
                        .country("USA")
                        .build())
                .thirdPartyCheck(1)
                .build();
        rest.put("api/outsourcer", outsourcerAfter);
        Assertions.assertEquals("Google", outsourcerAfter.getName());
    }

    @Test
    void shouldDeleteOutsourcerById() {
        int id =  Objects.requireNonNull(createOutsourcer().getBody()).getId();
        rest.delete("api/outsourcer/" + id, Outsourcer.class);
        try {
            Assertions.assertNull(outsourcerRepository.findById(id));
        } catch (LazyInitializationException e){
            System.out.println("Unable to find Outsourcer with id" + id + " " + e);
        }
    }

    @Test
    void lookupOutsourcerNotAvailable() {
        ResponseEntity<Outsourcer> httpEntity = rest.getForEntity("api/outsourcer/1234554",Outsourcer.class );

        Assertions.assertEquals(404, httpEntity.getStatusCodeValue());
    }

}
