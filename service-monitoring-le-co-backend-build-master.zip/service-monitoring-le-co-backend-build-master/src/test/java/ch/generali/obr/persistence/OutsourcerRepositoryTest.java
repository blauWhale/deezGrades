package ch.generali.obr.persistence;

import ch.generali.obr.model.Address;
import ch.generali.obr.model.Outsourcer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.in;

@DataJpaTest
public class OutsourcerRepositoryTest {

    @Autowired
    private OutsourcerRepository outsourcerRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private TestEntityManager em;

    private static Outsourcer outsourcer;
    private static Address address;

    @Test
    void shouldSaveOutsourcer(){
        address = Address.builder()
                .id(1)
                .city("Zurich")
                .street("Streetname 2")
                .country("Switzerland")
                .zipcode("8000")
                .build();
        outsourcer = Outsourcer.builder()
                .id(1)
                .contactPerson("test")
                .website("avanti.com")
                .name("avanti")
                .thirdPartyCheck(1)
                .address(address)
                .build();

        addressRepository.save(address);
        Outsourcer savedOutsourcer = outsourcerRepository.save(outsourcer);
        assertThat(savedOutsourcer).usingRecursiveComparison().ignoringFields("id").isEqualTo(outsourcer);
    }
}
