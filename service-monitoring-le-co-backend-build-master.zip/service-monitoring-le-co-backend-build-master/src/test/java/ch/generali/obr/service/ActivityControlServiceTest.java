package ch.generali.obr.service;

import ch.generali.obr.ObrServiceTestConfig;
import ch.generali.obr.model.*;
import ch.generali.obr.persistence.ActivityControlRepository;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

import java.sql.Date;
import java.util.Objects;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = ObrServiceTestConfig.class)
public class ActivityControlServiceTest {

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private ActivityControlRepository activityControlRepository;

    private static Report report;

    private static Activity activity;

    private static Outsourcing outsourcing;

    private static ActivityControl activityControl;

    @BeforeEach
    void setUp() {
        outsourcing = Outsourcing.builder()
                .outsourcer(Outsourcer.builder()
                        .name("Avanti")
                        .thirdPartyCheck(1)
                        .website("avanti.com")
                        .contactPerson("test")
                        .address(Address.builder()
                                .zipcode("8000")
                                .city("Zurich")
                                .street("Bahnhofstrasse 40")
                                .country("Switzerland")
                                .build())
                        .build())
                .name("Cloud storage solution")
                .beginDate(Date.valueOf("2022-02-02"))
                .endDate(Date.valueOf("2023-02-02"))
                .cloudOutsourcingCheck(true)
                .outg_id(null)
                .nonOutsourcing(false)
                .independent(true)
                .vulnerability(false)
                .qualitativeMateriality(false)
                .contractCategory(2)
                .build();

        outsourcing = rest.postForEntity("api/outsourcing", outsourcing, Outsourcing.class).getBody();
        activity = Activity.builder()
                .activity(1)
                .description("legal advice")
                .outsourcing(outsourcing)
                .build();
        activity = rest.postForEntity("api/outsourcing/"+ outsourcing.getId()  +"/activity", activity, Activity.class).getBody();

        report = Report.builder()
                .name("Q1 Report")
                .date(Date.valueOf("2022-02-02"))
                .approveBy("Raphael Blaauw")
                .approveDate(Date.valueOf("2022-02-12"))
                .outsourcing(outsourcing)
                .build();
        report = rest.postForEntity("api/outsourcing/"+ outsourcing.getId()  +"/report", report, Report.class).getBody();

        activityControl = ActivityControl.builder()
                .kpi("2")
                .contractReference("2000")
                .kpiControlActivity("do something")
                .evidence("here is what I did")
                .evidenceStorage("here is what I did")
                .riskDescription("a risk")
                .riskMitigation("a mitigation")
                .riskMitigationDate(Date.valueOf("2022-02-02"))
                .riskMitigationDeadline(Date.valueOf("2023-02-02"))
                .riskComment("a comment about the risk")
                .activity(activity)
                .report(report)
                .build();
    }

    public ResponseEntity<ActivityControl> createActivityControl(){
        int outsourcingId = Objects.requireNonNull(outsourcing).getId();
        return rest.postForEntity("api/outsourcing/"+ outsourcingId + "/report/"+ report.getId() +"/activity-control", activityControl, ActivityControl.class);

    }

    @Test
    public void createActivityControlSuccessfully(){
        Assertions.assertEquals(200, createActivityControl().getStatusCodeValue());
    }

    @Test
    public void lookupActivityControlAvailable() {
        ActivityControl activityControl =  createActivityControl().getBody();
        ResponseEntity<ActivityControl> httpEntity = rest.getForEntity("api/outsourcing/"+ outsourcing.getId() +"/report/" +  report.getId()+ "/activity-control/" + activityControl.getId(), ActivityControl.class );
        Assertions.assertEquals(200, httpEntity.getStatusCodeValue());
    }

    @Test
    void shouldUpdateActivityControlById() {
        ActivityControl activityControl =  createActivityControl().getBody();
        ActivityControl activityControlAfter = ActivityControl.builder()
                .kpi("2")
                .contractReference("2000")
                .kpiControlActivity("do something else")
                .evidence("here is what I did")
                .evidenceStorage("here is what I did")
                .riskDescription("a risk")
                .riskMitigation("a mitigation")
                .riskMitigationDate(Date.valueOf("2022-02-02"))
                .riskMitigationDeadline(Date.valueOf("2023-02-02"))
                .riskComment("a comment about the risk")
                .report(report)
                .activity(activity)
                .build();
        rest.put(urlBuilder(outsourcing.getId()
                ,report.getId(),
                activityControl.getId()),activityControlAfter);
        Assertions.assertEquals("do something else", activityControlAfter.getKpiControlActivity());
    }

    @Test
    void shouldDeleteActivityControlById() {
        int id =  Objects.requireNonNull(createActivityControl().getBody()).getId();
        rest.delete(urlBuilder(activityControl.getActivity().getOutsourcing().getId()
                ,activityControl.getReport().getId(),
                id), ActivityControl.class);
        try {
            Assertions.assertNull(activityControlRepository.getById(id));
        } catch (LazyInitializationException e){
            System.out.println("Unable to find activity control with id" + id + " " + e);
        }
    }

    @Test
    void lookupActivityControlNotAvailable() {
        ResponseEntity<ActivityControl> httpEntity = rest.getForEntity(urlBuilder(activityControl.getActivity().getOutsourcing().getId()
                ,activityControl.getReport().getId(),
                12345),ActivityControl.class );

        Assertions.assertEquals(404, httpEntity.getStatusCodeValue());
    }

    String urlBuilder(int outsourcingID, int reportID, int activityControlID){
        return "api/outsourcing/"+ outsourcingID +"/report/" +  reportID+ "/activity-control/" + activityControlID;
    }

}
