package ch.generali.obr.service;

import ch.generali.obr.ObrServiceTestConfig;
import ch.generali.obr.model.*;
import ch.generali.obr.model.Activity;
import ch.generali.obr.persistence.ActivityRepository;
import ch.generali.obr.persistence.ActivityRepository;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

import java.sql.Date;
import java.util.Objects;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = ObrServiceTestConfig.class)
public class ActivityServiceTest {

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private ActivityRepository activityRepository;

    private static Outsourcing outsourcing;

    private static Activity activity;

    @BeforeEach
    void setUp() {
        outsourcing = Outsourcing.builder()
                .outsourcer(Outsourcer.builder()
                        .name("Avanti")
                        .thirdPartyCheck(1)
                        .website("avanti.com")
                        .contactPerson("test")
                        .address(Address.builder()
                                .zipcode("8000")
                                .city("Zurich")
                                .street("Bahnhofstrasse 40")
                                .country("Switzerland")
                                .build())
                        .build())
                .name("Cloud storage solution")
                .beginDate(Date.valueOf("2022-02-02"))
                .endDate(Date.valueOf("2023-02-02"))
                .cloudOutsourcingCheck(true)
                .outg_id(null)
                .nonOutsourcing(false)
                .independent(true)
                .vulnerability(false)
                .qualitativeMateriality(false)
                .contractCategory(2)
                .build();

        outsourcing = rest.postForEntity("api/outsourcing", outsourcing, Outsourcing.class).getBody();
        activity = Activity.builder()
                .activity(1)
                .description("legal advice")
                .outsourcing(outsourcing)
                .build();
    }

    public ResponseEntity<Activity> createActivity(){
        int outsourcingId = Objects.requireNonNull(outsourcing).getId();
        ResponseEntity<Activity> httpEntity = rest.postForEntity("api/outsourcing/"+ outsourcingId  +"/activity", activity, Activity.class);
        return ResponseEntity.ok(httpEntity.getBody());
    }

    @Test
    public void createActivitySuccessfully(){
        Assertions.assertEquals(200, createActivity().getStatusCodeValue());
    }

    @Test
    public void lookupActivityAvailable() {
        Activity activity =  createActivity().getBody();
        ResponseEntity<Activity> httpEntity = rest.getForEntity("api/outsourcing/"+ activity.getOutsourcing().getId() +"api/activity/" + activity.getId(), Activity.class );
        Assertions.assertEquals(200, httpEntity.getStatusCodeValue());
    }

    @Test
    void shouldUpdateActivityById() {
        createActivity();
        Activity activityAfter = Activity.builder()
                .activity(1)
                .description("cloud storage")
                .outsourcing(outsourcing)
                .build();
        rest.put("api/outsourcing/"+ activity.getOutsourcing().getId() +"api/activity/", activityAfter);
        Assertions.assertEquals("cloud storage", activityAfter.getDescription());
    }

    @Test
    void shouldDeleteActivityById() {
        int id =  Objects.requireNonNull(createActivity().getBody()).getId();
        rest.delete("api/outsourcing/"+ activity.getOutsourcing().getId() +"api/activity/" + id, Activity.class);
        try {
            Assertions.assertNull(activityRepository.getById(id));
        } catch (LazyInitializationException e){
            System.out.println("Unable to find Activity with id" + id + " " + e);
        }
    }

    @Test
    void lookupActivityNotAvailable() {
        ResponseEntity<Activity> httpEntity = rest.getForEntity("api/outsourcing/"+ activity.getOutsourcing().getId() +"api/activity/1234554",Activity.class );

        Assertions.assertEquals(404, httpEntity.getStatusCodeValue());
    }

}
