package ch.generali.obr.persistence;

import ch.generali.obr.model.*;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.sql.Date;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
public class ActivityRepositoryTest {

    @Autowired
    private ActivityRepository activityRepository;

    private static Activity activity;

    @Test
    void shouldSaveOutsourcing(){
        activity = Activity.builder()
                .activity(1)
                .description("legal advice")
                .outsourcing(Outsourcing.builder()
                        .outsourcer(Outsourcer.builder()
                                .name("Avanti")
                                .thirdPartyCheck(1)
                                .website("avanti.com")
                                .contactPerson("test")
                                .address(Address.builder()
                                        .zipcode("8000")
                                        .city("Zurich")
                                        .street("Bahnhofstrasse 40")
                                        .country("Switzerland")
                                        .build())
                                .build())
                        .name("Consulting legal")
                        .beginDate(Date.valueOf("2022-02-02"))
                        .endDate(Date.valueOf("2023-02-02"))
                        .cloudOutsourcingCheck(true)
                        .outg_id(null)
                        .nonOutsourcing(false)
                        .independent(true)
                        .vulnerability(false)
                        .qualitativeMateriality(false)
                        .contractCategory(2)
                        .build())
                .build();

        Activity savedActivity = activityRepository.save(activity);
        assertThat(savedActivity).usingRecursiveComparison().ignoringFields("id").isEqualTo(activity);
    }
}
