package ch.generali.obr.service;

import ch.generali.obr.ObrServiceTestConfig;
import ch.generali.obr.model.Address;
import ch.generali.obr.model.Outsourcer;
import ch.generali.obr.model.Outsourcing;
import ch.generali.obr.persistence.OutsourcerRepository;
import ch.generali.obr.persistence.OutsourcingRepository;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.sql.Date;
import java.util.Objects;

@TestPropertySource(locations="classpath:application.properties")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = ObrServiceTestConfig.class)
public class OutsourcingServiceTest {

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private OutsourcingRepository outsourcingRepository;



    private static Outsourcing outsourcing;

    @BeforeEach
    void setUp() {
        outsourcing = Outsourcing.builder()
                .outsourcer(Outsourcer.builder()
                        .name("Avanti")
                        .thirdPartyCheck(1)
                        .website("avanti.com")
                        .contactPerson("test")
                        .address(Address.builder()
                                .zipcode("8000")
                                .city("Zurich")
                                .street("Bahnhofstrasse 40")
                                .country("Switzerland")
                                .build())
                        .build())
                .name("Cloud storage solution")
                .beginDate(Date.valueOf("2022-02-02"))
                .endDate(Date.valueOf("2023-02-02"))
                .cloudOutsourcingCheck(true)
                .outg_id(null)
                .nonOutsourcing(false)
                .independent(true)
                .vulnerability(false)
                .qualitativeMateriality(false)
                .contractCategory(2)
                .build();
    }

    public ResponseEntity<Outsourcing> createOutsourcing(){
        ResponseEntity<Outsourcing> httpEntity = rest.postForEntity("api/outsourcing", outsourcing, Outsourcing.class);
        return ResponseEntity.ok(httpEntity.getBody());
    }

    @Test
    void createSuccesful(){
        Assertions.assertEquals(200, createOutsourcing().getStatusCodeValue());
    }

    @Test
    public void lookupOutsourcingAvailable() {
        int id =  Objects.requireNonNull(createOutsourcing().getBody()).getId();
        ResponseEntity<Outsourcing> httpEntity = rest.getForEntity("api/outsourcing/" + id, Outsourcing.class );
        Assertions.assertEquals(200, httpEntity.getStatusCodeValue());
    }

    @Test
    void shouldUpdateOutsourcingById() {
        createOutsourcing();
        Outsourcing outsourcingAfter = Outsourcing.builder()
                .id(1)
                .outsourcer(Outsourcer.builder()
                        .id(1)
                        .name("Avanti")
                        .thirdPartyCheck(1)
                        .website("avanti.com")
                        .contactPerson("test")
                        .address(Address.builder()
                                .id(1)
                                .zipcode("8000")
                                .city("Zurich")
                                .street("Bahnhofstrasse 40")
                                .country("Switzerland")
                                .build())
                        .build())
                .name("Consulting legal")
                .beginDate(Date.valueOf("2022-02-02"))
                .endDate(Date.valueOf("2023-02-02"))
                .cloudOutsourcingCheck(true)
                .outg_id(null)
                .nonOutsourcing(false)
                .independent(true)
                .vulnerability(false)
                .contractCategory(2)
                .build();
        rest.put("api/outsourcing", outsourcingAfter);
        Assertions.assertEquals("Consulting legal", outsourcingAfter.getName());
    }

    @Test
    void shouldDeleteOutsourcingById() {
        int id = Objects.requireNonNull(createOutsourcing().getBody()).getId();
        rest.delete("api/outsourcing/" + id, Outsourcing.class);
        try {
            Assertions.assertNull(outsourcingRepository.getOutsourcingById(id));
        } catch (LazyInitializationException e){
            System.out.println("Unable to find Outsourcing with id" + id + " " + e);
        }
    }

    @Test
    void lookupOutsourcingNotAvailable() {
        ResponseEntity<Outsourcing> httpEntity = rest.getForEntity("api/outsourcing/1234554",Outsourcing.class );
        Assertions.assertEquals(404, httpEntity.getStatusCodeValue());
    }

}
