package ch.generali.obr.persistence;

import ch.generali.obr.model.Address;
import ch.generali.obr.model.Outsourcer;
import ch.generali.obr.model.Outsourcing;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.sql.Date;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
public class OutsourcingRepositoryTest {

    @Autowired
    private OutsourcingRepository outsourcingRepository;
    @Autowired
    private OutsourcerRepository outsourcerRepository;
    @Autowired
    private AddressRepository addressRepository;

    private static Outsourcing outsourcing;

    private static Outsourcer outsourcer;
    private static Address address;

    @Test
    void shouldSaveOutsourcing(){
        address = Address.builder()
                .city("Zurich")
                .street("Streetname 2")
                .country("Switzerland")
                .zipcode("8000")
                .build();
        outsourcer = Outsourcer.builder()
                .contactPerson("test")
                .website("avanti.com")
                .name("avanti")
                .thirdPartyCheck(1)
                .address(address)
                .build();

        outsourcing = Outsourcing.builder()
                .outsourcer(outsourcer)
                .name("Cloud storage solution")
                .beginDate(Date.valueOf("2022-02-02"))
                .endDate(Date.valueOf("2032-02-02"))
                .cloudOutsourcingCheck(true)
                .outg_id(null)
                .nonOutsourcing(false)
                .independent(true)
                .vulnerability(false)
                .qualitativeMateriality(false)
                .contractCategory(2)
                .build();

        addressRepository.save(address);
        outsourcerRepository.save(outsourcer);
        Outsourcing savedOutsourcing = outsourcingRepository.save(outsourcing);
        assertThat(savedOutsourcing).usingRecursiveComparison().ignoringFields("id").isEqualTo(outsourcing);
    }
}
