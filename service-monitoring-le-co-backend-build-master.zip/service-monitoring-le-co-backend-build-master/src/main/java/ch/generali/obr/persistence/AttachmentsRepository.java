package ch.generali.obr.persistence;

import ch.generali.obr.model.Attachments;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttachmentsRepository extends JpaRepository<Attachments, Integer> {
}
