package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Date;

@Getter
@Setter
@Entity(name = "answer")
@Table(name = "answer")
@GeneraliTablePrefix("answ")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Answer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String comment;

    @NotNull
    private Date createdAt;

    @NotNull
    private boolean answer;

    private String reasonOfRiskscore;

    private String riskscore;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "answ_ques_id")
    @JsonIgnore
    private Question question;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "answ_repo_id")
    @JsonIgnore
    private Report report;
}
