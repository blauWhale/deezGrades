package ch.generali.obr.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class FormWrapper {

    Outsourcing outsourcing;

    Activity activity;
}
