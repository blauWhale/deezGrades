package ch.generali.obr.service;

import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.model.Outsourcer;
import ch.generali.obr.model.Outsourcing;
import ch.generali.obr.persistence.OutsourcingRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class OutsourcingService {

    @Autowired
    OutsourcingRepository outsourcingRepository;

    @Operation(summary = "Create Service",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Service",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcing.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return Empty List", content = @Content)
            })
    @PostMapping(value = "/outsourcing")
    @Transactional
    public ResponseEntity<Outsourcing> createOutsourcing(@RequestBody Outsourcing outsourcing) {
        Optional<Outsourcing> outsourcingOptional = Optional.of(outsourcingRepository.save(outsourcing));
        return ResponseEntity.ok(outsourcingOptional.get());

    }

    @Operation(summary = "GET Service",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Found Service",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcing.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/outsourcing/{id}")
    @Transactional
    public ResponseEntity<Outsourcing> getOutsourcingById(@Parameter(description = "id of service to be searched")
            @PathVariable int id) {
        Optional<Outsourcing> outsourcing = outsourcingRepository.getOutsourcingById(id);
        if (outsourcing.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(outsourcing.get());
        }
    }

    @Operation(summary = "Update Service",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Service",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcing.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Service not found", content = @Content)
            })
    @PutMapping(value = "/outsourcing/{id}")
    @Transactional
    public ResponseEntity<Outsourcing> updateOutsourcing(@RequestBody Outsourcing updatedOutsourcing) {
        Optional<Outsourcing> outsourcing = Optional.of(outsourcingRepository.save(updatedOutsourcing));
        if (outsourcing.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(outsourcing.get());
        }

    }

    @Operation(summary = "Delete Service",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Deleted Service",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcing.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Service not found", content = @Content)
            })
    @DeleteMapping(value = "/outsourcing/{id}")
    @Transactional
    @CrossOrigin(origins = "http://localhost:3000/")
    public void deleteOutsourcing(@Parameter(description = "id of service to be deleted")
                                      @PathVariable int id) {
        outsourcingRepository.deleteOutsourcingById(id);
    }

    @Operation(summary = "GET ALL Services",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Found all Services",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcing.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/outsourcing")
    @CrossOrigin(origins = "http://localhost:3000/")
    public ResponseEntity<Page<Outsourcing>> getAllOutsourcing(@Parameter(description = "page where the provider can be found") @RequestParam int page,
                                                               @Parameter(description = "sort providers function") @RequestParam String sort,
                                                               @Parameter(description = "ascending variable used to sort") @RequestParam boolean asc,
                                                               @Parameter(description = "Keyword to do search on") @RequestParam(required = false)String search) {
        Pageable firstPageWithTwoElements;
        if (asc) {
            firstPageWithTwoElements = PageRequest.of(page, 2, Sort.by(sort).ascending());
        } else {
            firstPageWithTwoElements = PageRequest.of(page, 2, Sort.by(sort).descending());
        }
        Optional<Page<Outsourcing>> outsourcing;
        if(search == null ){
            outsourcing = Optional.of(outsourcingRepository.findAll(firstPageWithTwoElements));
        }else{
            outsourcing = Optional.of(outsourcingRepository.findByNameContaining(search, firstPageWithTwoElements));
        }
        return outsourcing.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());

    }
}
