package ch.generali.obr.service;

import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.persistence.ActivityControlRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/outsourcing/{id}/activity/{id}")
public class ActivityControlService {

    @Autowired
    ActivityControlRepository activityControlRepository;

    @Operation(summary = "Create Activity Control by Outsourcing & Activity id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Activity Control",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ActivityControl.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Activity Control couldn't be created", content = @Content)
    })
    @PostMapping(value = "/activity-control")
    @Transactional
    public ResponseEntity<ActivityControl> createActivityControl(@Parameter(description = "id of Service and Activity Required")
                                                                     @RequestBody ActivityControl activityControl) {
        ActivityControl activityControlOptional = activityControlRepository.save(activityControl);
        return ResponseEntity.ok(activityControlOptional);

    }

    @Operation(summary = "Get Activity Control by Outsourcing & Activity id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully GET Activity Control",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ActivityControl.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/activity-control/{id}")
    @Transactional
    public ResponseEntity<ActivityControl> getActivityControl(@Parameter(description = "id of activity control to be searched")
                                                                  @PathVariable int id) {
        Optional<ActivityControl> activityControl = activityControlRepository.getActivityControlById(id);
        if (activityControl.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(activityControl.get());
        }
    }

    @Operation(summary = "Update Activity Control by Outsourcing & Activity id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Activity Control",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ActivityControl.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Something went wrong", content = @Content)
            })
    @PutMapping(value = "/activity-control/{id}")
    @Transactional
    public ResponseEntity<ActivityControl> updateActivityControl(@Parameter(description = "id of activity control to be updated")
                                                                     @RequestBody ActivityControl updatedActivityControl) {
        Optional<ActivityControl> activityControl = Optional.of(activityControlRepository.save(updatedActivityControl));
        if (activityControl.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(activityControl.get());
        }

    }

    @Operation(summary = "Delete Activity Control by Outsourcing & Activity id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Deleted Activity Control",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ActivityControl.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Activity Control couldnt be found", content = @Content)
            })
    @DeleteMapping(value = "/activity-control/{id}")
    @Transactional
    public void deleteActivityControl(@Parameter(description = "id of activity control to be deleted")
                                          @PathVariable int id) {
        activityControlRepository.deleteActivityControlById(id);
    }

}
