package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@Entity(name = "outsourcer")
@Table(name = "outsourcer")
@GeneraliTablePrefix("outr")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class  Outsourcer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    private String name;

    @NotBlank
    private String contactPerson;

    @NotBlank
    private String website;

    @NotNull
    private Integer thirdPartyCheck;

    @NotNull
    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL )
    @JoinColumn(name = "outr_addr_id")
    @JsonIgnore
    private Address address;
}
