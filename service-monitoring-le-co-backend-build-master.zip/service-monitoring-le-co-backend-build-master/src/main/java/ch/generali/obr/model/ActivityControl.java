package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.sql.Date;

@Getter
@Setter
@Entity(name = "activity_control")
@Table(name = "activity_control")
@GeneraliTablePrefix("acco")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ActivityControl {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    private String kpi;

    @NotBlank
    private String contractReference;

    @NotBlank
    private String kpiControlActivity;

    private String evidence;

    private String evidenceStorage;

    private String riskDescription;

    private String riskMitigation;

    private Date riskMitigationDate;

    private Date riskMitigationDeadline;

    private String riskComment;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "acco_repo_id")
    @JsonIgnore
    private Report report;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "acco_acti_id")
    @JsonIgnore
    private Activity activity;



}
