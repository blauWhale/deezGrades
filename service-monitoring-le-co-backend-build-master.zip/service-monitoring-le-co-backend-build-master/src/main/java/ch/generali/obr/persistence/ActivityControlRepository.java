package ch.generali.obr.persistence;

import ch.generali.obr.model.ActivityControl;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ActivityControlRepository extends JpaRepository<ActivityControl, Integer> {

    Optional<ActivityControl> getActivityControlById(int id);

    void deleteActivityControlById(int id);
}
