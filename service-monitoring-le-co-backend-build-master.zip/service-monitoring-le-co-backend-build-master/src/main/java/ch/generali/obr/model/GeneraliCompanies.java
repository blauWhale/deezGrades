package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@Entity(name = "generali_companies")
@Table(name = "generali_companies")
@GeneraliTablePrefix("geco")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GeneraliCompanies {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull
    private Integer company;

    private Integer quantitativeMaterialityValue;

    private Integer quantitativeMaterialityReference;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "geco_outg_id")
    @JsonIgnore
    private Outsourcing outsourcing;

}
