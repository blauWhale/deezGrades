package ch.generali.obr.service;

import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.model.Question;
import ch.generali.obr.persistence.QuestionRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api")
public class QuestionService {

    @Autowired
    QuestionRepository questionRepository;

    @Operation(summary = "Create Question",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Question",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Question.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Question couldn't be created", content = @Content)
            })
    @PostMapping(value = "/question")
    @Transactional
    public ResponseEntity<Question> createQuestion(@RequestBody Question question) {
        Question questionOptional = questionRepository.save(question);
        return ResponseEntity.ok(questionOptional);

    }

    @Operation(summary = "Get Question",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Found Question",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Question.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/question/{id}")
    @Transactional
    public ResponseEntity<Question> getQuestionById(@Parameter(description = "id of question to be found")
                                                        @PathVariable int id) {
        Optional<Question> question = questionRepository.getQuestionById(id);
        if (question.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(question.get());
        }
    }

    @Operation(summary = "Update Question",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Question",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Question.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @PutMapping(value = "/question/{id}")
    @Transactional
    public ResponseEntity<Question> updateQuestion(@RequestBody Question updatedQuestion) {
        Optional<Question> question = Optional.of(questionRepository.save(updatedQuestion));
        if (question.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(question.get());
        }

    }

    @Operation(summary = "Delete Question",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Deleted Question",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Question.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Question couldn't be found", content = @Content)
            })
    @DeleteMapping(value = "/question/{id}")
    @Transactional
    public void deleteQuestion(@Parameter(description = "id of question to be deleted")
                                   @PathVariable int id) {
        questionRepository.deleteQuestionById(id);
    }

}
