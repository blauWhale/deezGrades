package ch.generali.obr.persistence;

import ch.generali.obr.model.Report;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ReportRepository extends JpaRepository<Report, Integer> {

    Optional<Report> getReportById(int id);

    void deleteReportById(int id);
}
