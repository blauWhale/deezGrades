package ch.generali.obr.service;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.springframework.validation.FieldError;

@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class FieldErrorResponse {
    private final String field;
    private final String[] codes;
    private final String objectName;
    private final Object rejectedValue;

    public FieldErrorResponse(FieldError fieldError) {
        this(fieldError.getField(), fieldError.getCodes(), fieldError.getObjectName(), fieldError.getRejectedValue());
    }
}
