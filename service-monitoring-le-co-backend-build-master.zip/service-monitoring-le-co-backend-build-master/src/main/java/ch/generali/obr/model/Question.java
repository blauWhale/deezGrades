package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@Entity(name = "question")
@Table(name = "question")
@GeneraliTablePrefix("ques")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    private String question;

    @NotBlank
    private String category;

    @NotNull
    private Integer catalog;
}
