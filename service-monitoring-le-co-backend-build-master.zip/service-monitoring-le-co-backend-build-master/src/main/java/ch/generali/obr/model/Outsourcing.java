package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.sql.Date;

@Getter
@Setter
@Entity(name = "outsourcing")
@Table(name = "outsourcing")
@GeneraliTablePrefix("outg")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Outsourcing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    private String name;

    @NotNull
    private Date beginDate;

    @NotNull
    private Date endDate;

    @NotNull
    private boolean cloudOutsourcingCheck;

    @NotNull
    private boolean nonOutsourcing;

    @NotNull
    private boolean independent;

    @NotNull
    private boolean vulnerability;

    @NotNull
    private boolean qualitativeMateriality;

    @NotNull
    private Integer contractCategory;

    private Integer outg_id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
    @JoinColumn(name = "outg_outr_id")
    @JsonIgnore
    private Outsourcer outsourcer;

}
