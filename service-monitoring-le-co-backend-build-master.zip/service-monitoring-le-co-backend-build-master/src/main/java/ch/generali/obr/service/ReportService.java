package ch.generali.obr.service;

import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.model.Report;
import ch.generali.obr.persistence.ReportRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/outsourcing/{id}")
public class ReportService {

    @Autowired
    ReportRepository reportRepository;

    @Operation(summary = "Create Report",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Report",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Report.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Report couldn't be created", content = @Content)
            })
    @PostMapping(value = "/report")
    @Transactional
    public ResponseEntity<Report> createReport(@RequestBody Report report) {
        Report reportOptional = reportRepository.save(report);
        return ResponseEntity.ok(reportOptional);

    }

    @Operation(summary = "Get Report",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Found Report",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Report.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/report/{id}")
    @Transactional
    public ResponseEntity<Report> getReportById(@Parameter(description = "id of report to be searched")
                                                    @PathVariable int id) {
        Optional<Report> report = reportRepository.getReportById(id);
        if (report.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(report.get());
        }
    }

    @Operation(summary = "Update Report",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Report",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Report.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Report couldn't be updated", content = @Content)
            })
    @PutMapping(value = "/report/{id}")
    @Transactional
    public ResponseEntity<Report> updateReport(@RequestBody Report updatedReport) {
        Optional<Report> report = Optional.of(reportRepository.save(updatedReport));
        if (report.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(report.get());
        }

    }

    @Operation(summary = "Delete Report",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully deleted Report",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Report.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Report couldn't be deleted", content = @Content)
            })
    @DeleteMapping(value = "/report/{id}")
    @Transactional
    public void deleteReport(@Parameter(description = "id of report to be deleted")
                                 @PathVariable int id) {
        reportRepository.deleteReportById(id);
    }

    @Operation(summary = "Get all Reports",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Found all Reports",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Report.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/report/all")
    public ResponseEntity<List<Report>> getAllReport() {
        Optional<List<Report>> allReport = Optional.of(reportRepository.findAll());
        if (allReport.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(allReport.get());
        }
    }
}
