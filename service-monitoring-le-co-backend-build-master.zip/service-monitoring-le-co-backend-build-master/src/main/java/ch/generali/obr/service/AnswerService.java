package ch.generali.obr.service;

import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.model.Answer;
import ch.generali.obr.persistence.AnswerRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class AnswerService {

    @Autowired
    AnswerRepository answerRepository;

    @Operation(summary = "Create Answer",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Answer",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Answer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Answer couldn't be created", content = @Content)
            })
    @PostMapping(value = "/answer")
    @Transactional
    public ResponseEntity<Answer> createAnswer(@RequestBody Answer answer) {
        Answer answerOptional = answerRepository.save(answer);
        return ResponseEntity.ok(answerOptional);

    }

    @Operation(summary = "GET Answer",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Answer",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Answer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @PutMapping(value = "/answer/{id}")
    @Transactional
    public ResponseEntity<Answer> getAnswer(@Parameter(description = "answer id to be found") @PathVariable int id) {
        Optional<Answer> answer = answerRepository.getAnswerById(id);
        if (answer.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(answer.get());
        }
    }

    @Operation(summary = "Delete Answer",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Deleted Answer",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Answer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Answer couldnt be found", content = @Content)
            })
    @DeleteMapping(value = "/answer/{id}")
    @Transactional
    public void deleteAnswer(@Parameter(description = "answer id to be deleted")
                                 @PathVariable int id) {
        answerRepository.deleteAnswerById(id);
    }

    @Operation(summary = "Get All Answers",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Got all Answers",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Answer.class))}),
                    @ApiResponse(responseCode = "400", description = "Something went wrong", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/answer/all")
    public ResponseEntity<List<Answer>> getAllAnswer() {
        Optional<List<Answer>> allAnswer = Optional.of(answerRepository.findAll());
        if (allAnswer.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(allAnswer.get());
        }
    }
}
