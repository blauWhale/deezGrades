package ch.generali.obr.model;

import ch.generali.obr.persistence.strategy.GeneraliTablePrefix;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@Entity(name = "activity")
@Table(name = "activity")
@GeneraliTablePrefix("acti")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Activity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull
    private Integer activity;

    @NotBlank
    private String description;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "acti_outg_id")
    @JsonIgnore
    private Outsourcing outsourcing;
}
