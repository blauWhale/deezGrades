package ch.generali.obr.persistence.strategy;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.ImplicitBasicColumnNameSource;
import org.hibernate.boot.model.naming.ImplicitJoinColumnNameSource;
import org.hibernate.boot.model.naming.ImplicitNamingStrategyComponentPathImpl;
import org.hibernate.cfg.Ejb3Column;
import java.lang.reflect.Field;
import java.util.Locale;

public class CustomImplicitNamingStrategy extends ImplicitNamingStrategyComponentPathImpl {

    @Override
    public Identifier determineJoinColumnName(ImplicitJoinColumnNameSource source) {
        String name = source.getReferencedColumnName().toString();
        Identifier identifier = toIdentifier(name, source.getBuildingContext());
        return identifier;
    }

    @Override
    public Identifier determineBasicColumnName(ImplicitBasicColumnNameSource source) {
        try {
            Field ejb3ColumnField = source.getClass().getDeclaredField("this$0");
            ejb3ColumnField.setAccessible(true);
            Ejb3Column ejb3Column = (Ejb3Column) ejb3ColumnField.get(source);
            Class table = Class.forName(ejb3Column.getPropertyHolder().getClassName());
            if (!table.isAnnotationPresent(GeneraliTablePrefix.class)) {
                throw new RuntimeException("GeneraliTablePrefix annotation is mandatory");
            }
            // explicit naming oder implicit
            String tableName = ((GeneraliTablePrefix) table.getAnnotation(GeneraliTablePrefix.class)).value();
            final Identifier basicColumnName = super.determineBasicColumnName(source);
            String columnName = tableName + "_" + basicColumnName.toString();

            return Identifier.toIdentifier(columnName);
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
