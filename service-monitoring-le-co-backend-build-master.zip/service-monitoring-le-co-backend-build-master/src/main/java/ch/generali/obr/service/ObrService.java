package ch.generali.obr.service;

import ch.generali.obr.model.Activity;
import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.model.FormWrapper;
import ch.generali.obr.model.Outsourcing;
import ch.generali.obr.persistence.ActivityRepository;
import ch.generali.obr.persistence.OutsourcingRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("/api")
public class ObrService {

    @Autowired
    OutsourcingRepository outsourcingRepository;

    @Autowired
    ActivityRepository activityRepository;

    @Operation(summary = "Create Obr(Form Wrapper, currently includes Outsourcing and Activity)",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Obr",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = FormWrapper.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @PostMapping("/obr")
    @Transactional
    public ResponseEntity<FormWrapper> createObr(@RequestBody @Valid FormWrapper request){
        return saveDataInFormWrapper(request);
    }

    @Operation(summary = "Update Obr(Form Wrapper, currently includes Outsourcing and Activity)",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Obr",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = FormWrapper.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @PutMapping("/obr")
    @Transactional
    public ResponseEntity<FormWrapper> updateObr(@RequestBody @Valid FormWrapper request){
        return saveDataInFormWrapper(request);
    }

    private ResponseEntity<FormWrapper> saveDataInFormWrapper(FormWrapper request){
        Outsourcing savedOutsourcing = outsourcingRepository.save(request.getOutsourcing());
        Activity savedActivity = activityRepository.save(request.getActivity());

        FormWrapper response = FormWrapper.builder()
                .outsourcing(savedOutsourcing)
                .activity(savedActivity)
                .build();
        return ResponseEntity.ok(response);
    }
}
