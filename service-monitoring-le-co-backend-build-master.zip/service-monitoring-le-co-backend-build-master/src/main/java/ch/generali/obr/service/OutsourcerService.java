package ch.generali.obr.service;

import ch.generali.obr.model.ActivityControl;
import ch.generali.obr.model.Address;
import ch.generali.obr.model.Outsourcer;
import ch.generali.obr.persistence.AddressRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import ch.generali.obr.persistence.OutsourcerRepository;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api") //to be changed
public class OutsourcerService {

    @Autowired
    OutsourcerRepository outsourcerRepository;

    @Autowired
    AddressRepository addressRepository;

    @Operation(summary = "Create Provider",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Provider",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Something went wrong", content = @Content)
            })
    @PostMapping(value = "/outsourcer")
    @Transactional
    public ResponseEntity<Outsourcer> createOutsourcer(@RequestBody @Valid Outsourcer request) {
        return persistOutsourcer(request);
    }

    @Operation(summary = "Update Provider",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully updated Provider",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Something went wrong", content = @Content)
            })
    @PutMapping(value = "/outsourcer")
    @Transactional
    public ResponseEntity<Outsourcer> updateOutsourcerById(@RequestBody @Valid Outsourcer request) {
        return persistOutsourcer(request);
    }

    private ResponseEntity<Outsourcer> persistOutsourcer(Outsourcer request) {
        Optional<Address> savedAddress = Optional.of(addressRepository.save(request.getAddress()));
        request.setAddress(savedAddress.get());
        Optional<Outsourcer> savedOutsourcer = Optional.of(outsourcerRepository.save(request));
        return ResponseEntity.ok(savedOutsourcer.get());
    }

    @Operation(summary = "Delete Provider",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Deleted Provider",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Something went wrong", content = @Content)
            })
    @DeleteMapping(value = "/outsourcer/{id}")
    @Transactional
    @CrossOrigin(origins = "http://localhost:3000/")
    public void deleteOutsourcerById(@Parameter(description = "id of provider to be deleted")
                                     @PathVariable int id) {
        outsourcerRepository.deleteOutsourcerById(id);
    }

    @Operation(summary = "Get Provider",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Got Provider",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/outsourcer/{id}")
    @Transactional
    public ResponseEntity<Outsourcer> getOutsourcerById(@Parameter(description = "id of provider to be searched")
                                                        @PathVariable int id) {
        Optional<Outsourcer> outsourcer = outsourcerRepository.findById(id);
        return outsourcer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get all Providers",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Got all Providers",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Outsourcer.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })

    @GetMapping(value = "/outsourcer")
    @CrossOrigin(origins = "http://localhost:3000/")
    @Transactional
    public ResponseEntity<Page<Outsourcer>> getAllOutsourcer(@Parameter(description = "page where the provider can be found") @RequestParam int page,
                                                             @Parameter(description = "sort providers function") @RequestParam String sort,
                                                             @Parameter(description = "ascending variable used to sort") @RequestParam boolean asc,
                                                             @Parameter(description = "Keyword to do search on") @RequestParam(required = false)String search) {
        Pageable firstPageWithTwoElements;
        if (asc) {
            firstPageWithTwoElements = PageRequest.of(page, 2, Sort.by(sort).ascending());
        } else {
            firstPageWithTwoElements = PageRequest.of(page, 2, Sort.by(sort).descending());
        }
        Optional<Page<Outsourcer>> outsourcer;
        if(search == null ){
             outsourcer = Optional.of(outsourcerRepository.findAll(firstPageWithTwoElements));
        }else{
             outsourcer = Optional.of(outsourcerRepository.findByNameContaining(search, firstPageWithTwoElements));
        }
        return outsourcer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
