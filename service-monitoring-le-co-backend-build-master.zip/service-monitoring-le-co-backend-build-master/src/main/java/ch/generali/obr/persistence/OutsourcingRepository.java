package ch.generali.obr.persistence;

import ch.generali.obr.model.Outsourcer;
import ch.generali.obr.model.Outsourcing;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

public interface OutsourcingRepository extends PagingAndSortingRepository<Outsourcing, Integer> {

    Optional<Outsourcing> getOutsourcingById(int id);

    Page<Outsourcing> findByNameContaining(String name, Pageable pageable);

    void deleteOutsourcingById(int id);
}
