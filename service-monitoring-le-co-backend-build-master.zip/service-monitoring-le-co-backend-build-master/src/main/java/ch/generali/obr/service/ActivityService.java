package ch.generali.obr.service;

import ch.generali.obr.model.Activity;
import ch.generali.obr.persistence.ActivityRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/outsourcing/{id}")
public class ActivityService {

    @Autowired
    ActivityRepository activityRepository;

    @Operation(summary = "Create Activity by Outsourcing id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Created Activity",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Activity.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Activity couldn't be created", content = @Content)
            })
    @PostMapping(value = "/activity")
    @Transactional
    public ResponseEntity<Activity> createActivity(@RequestBody Activity activity) {
        Activity activityOptional = activityRepository.save(activity);
        return ResponseEntity.ok(activityOptional);

    }

    @Operation(summary = "Get Activity by Outsourcing id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Got Activity",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Activity.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Return empty List", content = @Content)
            })
    @GetMapping(value = "/activity/{id}")
    @Transactional
    public ResponseEntity<Activity> getActivity(@Parameter(description = "id of activity to be searched")
                                                    @PathVariable int id) {
        Optional<Activity> activity = activityRepository.getActivityById(id);
        if (activity.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(activity.get());
        }
    }

    @Operation(summary = "Update Activity by Outsourcing id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Updated Activity",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Activity.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Activity couldnt be found", content = @Content)
            })
    @PutMapping(value = "/activity/{id}")
    @Transactional
    public ResponseEntity<Activity> updateActivity(@Parameter(description = "id of activity to be updated")
                                                       @RequestBody Activity updatedActivity) {
        Optional<Activity> activity = Optional.of(activityRepository.save(updatedActivity));
        if (activity.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(activity.get());
        }

    }

    @Operation(summary = "Delete Activity by Outsourcing id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successfully Deleted Activity",
                            content ={ @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = Activity.class))}),
                    @ApiResponse(responseCode = "400", description = "Invalid Input", content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = FieldErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Activity couldnt be found", content = @Content)
            })
    @DeleteMapping(value = "/activity/{id}")
    @Transactional
    public void deleteActivity(@Parameter(description = "id of activity to be deleted")
                                   @PathVariable int id) {
        activityRepository.deleteActivityById(id);
    }

}
