package ch.generali.obr.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.persistence.EntityNotFoundException;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class RestExceptionHandler {

    /**
     * Will handle any exception of type {@link MethodArgumentNotValidException}
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<List<FieldErrorResponse>> handle(MethodArgumentNotValidException exception) {
        log.debug("handle exception", exception);
        List<FieldErrorResponse> fieldErrorResponses = exception.getFieldErrors().stream().map(FieldErrorResponse::new).collect(Collectors.toList());
        return ResponseEntity.badRequest().body(fieldErrorResponses);
    }


    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<List<FieldErrorResponse>> handle(ConstraintViolationException exception) {
        log.debug("handle exception", exception);
        List<FieldErrorResponse> fieldErrorResponses = exception.getConstraintViolations().stream().map(e -> new FieldErrorResponse(e.getPropertyPath().toString(), null, null, e.getInvalidValue())).collect(Collectors.toList());
        return ResponseEntity.badRequest().body(fieldErrorResponses);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity handle(EntityNotFoundException exception) {
        log.debug("handle exception", exception);
        return ResponseEntity.notFound().build();
    }

}
