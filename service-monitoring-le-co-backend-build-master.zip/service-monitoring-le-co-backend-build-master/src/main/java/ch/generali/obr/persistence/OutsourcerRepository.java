package ch.generali.obr.persistence;

import ch.generali.obr.model.Outsourcer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;


public interface OutsourcerRepository extends PagingAndSortingRepository<Outsourcer, Integer> {

    void deleteOutsourcerById(int id);

    Page<Outsourcer> findByNameContaining(String name, Pageable pageable);

}
