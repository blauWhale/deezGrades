import React from "react"
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom"
import './index.css';

import Homepage from "./pages/Homepage"
import Sidebar from "./components/Sidebar"
import ProviderCreation from "./pages/ProviderCreation"

import { Container, Col, Row } from "react-bootstrap"
import ProviderUpdate from "./pages/ProviderUpdate";


function App() {
    return (
        <div style={{height: '100%'}} className="App">
            <div className="with-sidebar">
                <div><Sidebar /></div>
                <div>
                    <Router>
                        <Routes>
                            <Route path="/" element={<Navigate to="/provider" />} />
                            <Route exact path="/provider" element={<Homepage />} />
                            <Route path="/service" element={<Homepage />} />
                            <Route path="/provider/new" element={<ProviderCreation />} />
                            <Route path="/provider/update/:id" element={<ProviderUpdate />} />
                        </Routes>
                    </Router>
                </div>
            </div>
        </div>
    )
}

export default App;
