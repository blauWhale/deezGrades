import React, { useState } from 'react';
import { Nav, Button, Collapse } from 'react-bootstrap';
import "../index.css"

function Sidebar() {
    const [providerOpen, setProviderOpen] = useState(false);
    const [serviceOpen, setServiceOpen] = useState(false);

    return (
        <div className="heightFull" style={{ position: 'relative', width: '100%' }}>
            <h5 style={{ marginBottom: '5px', marginLeft: "5px" }}>
                ServiceMonitoringLeCo
            </h5>

            <div onClick={() => setProviderOpen(!providerOpen)} className="d-flex justify-content" style={{ margin: '30px 30px 10px 30px' }}>
                {providerOpen ? <i className="bi bi-caret-down-fill"/> : <i className="bi bi-caret-right"/>}

                <h6
                    aria-controls="service-fade-text"
                    aria-expanded={providerOpen}
                    style={{ marginLeft: '12px', fontSize: '18px' }}
                >
                    Provider
                </h6>
            </div>
            <Collapse in={providerOpen}>
                <div id="service-fade-text">
                    <ul style={{ marginLeft: '26px', fontSize: '16px' }}>
                        <a href="/provider" className="paragraphStyle"><p>List all providers</p></a>
                        <a href="/provider/new" className="paragraphStyle"><p>Create new provider</p></a>
                    </ul>
                </div>
            </Collapse>

            <div onClick={() => setServiceOpen(!serviceOpen)} className="d-flex justify-content" style={{ margin: '30px 30px 10px 30px' }}>
                {serviceOpen ? <i className="bi bi-caret-down-fill"/> : <i className="bi bi-caret-right"/>}

                <h6
                    aria-controls="service-fade-text"
                    aria-expanded={serviceOpen}
                    style={{ marginLeft: '12px', fontSize: '18px' }}
                >
                    Service
                </h6>
            </div>
            <Collapse in={serviceOpen}>
                <div id="service-fade-text">
                    <ul style={{ marginLeft: '26px', fontSize: '16px' }}>
                        <a href="/service" className="paragraphStyle"><p>List all services</p></a>
                        <a href="/service/new" className="paragraphStyle"><p>Create new service</p></a>
                    </ul>
                </div>
            </Collapse>

            <div style={{marginTop: '30px'}}>
                <ul>
                    <p>General Information</p>
                    <p>Due Diligence</p>
                    <p>Monitoring</p>
                    <p>Control</p>
                </ul>
            </div>

            <div style={{ position: 'absolute', bottom: '0px', width: '100%', padding: '5px' }}>
                <Button className="logout-btn" variant="light">Logout</Button>
            </div>
        </div >

    )
}

export default Sidebar
