import React, {forwardRef, useRef} from "react"
import {Form, Button, Card, Row, Col} from "react-bootstrap"
import {useNavigate} from "react-router-dom"
import CountryList from "../components/CountryList"
import withReactContent from 'sweetalert2-react-content'
import Swal from "sweetalert2";

function ProviderCreation() {
    let navigate = useNavigate()
    const MySwal = withReactContent(Swal)
    const providerRef = useRef("")
    const contactPersonRef = useRef("")
    const thirdPartyCheckRef = useRef("")
    const websiteRef = useRef("")
    const streetRef = useRef("")
    const cityRef = useRef("")
    const countryRef = useRef("")
    const zipcodeRef = useRef("")
    const CountryListComponent = forwardRef((props, ref) => (
        <CountryList countryRef={ref}/>
    ));

    const createProvider = async () => {
        return await fetch("http://localhost:8080/api/provider"
            , {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                mode: 'cors',
                body: JSON.stringify({
                    "name": providerRef.current.value,
                    "contactPerson": contactPersonRef.current.value,
                    "thirdPartyCheck": parseInt(thirdPartyCheckRef.current.value),
                    "website": websiteRef.current.value,
                    "address": {
                        "street": streetRef.current.value,
                        "city": cityRef.current.value,
                        "zipcode": zipcodeRef.current.value,
                        "country": countryRef.current.value,
                    }
                })
            })
            .then(res => {
                if(res.status === 200){
                    MySwal.fire(
                        'Success',
                        'Provider has been created!',
                        'success'
                    )
                    navigate('/provider')
                }
            })
            .catch(err=>{
                MySwal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: err
                })
            })

    }

    return (
        <Card className="border-0 shadow p-3 mb-5 bg-white mt-5 roundedBorder mx-2">
            <Card.Body>
                <Form>
                    <Row>
                        <Col sm={5}>
                            <h5>General Information</h5>
                        </Col>
                        <Col sm={7}>
                            <Row>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Provider Name</Form.Label>
                                        <Form.Control type="text" placeholder="Name" ref={providerRef}/>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Contact Person</Form.Label>
                                        <Form.Control type="text" placeholder="Contact Person"
                                                      ref={contactPersonRef}/>
                                    </Form.Group>
                                </Col>
                            </Row>

                            <Row>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Website</Form.Label>
                                        <Form.Control type="text" placeholder="https://www.example.com"
                                                      ref={websiteRef}/>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group>
                                        <Form.Label>Intra-Group / Third-Party</Form.Label>
                                        <Form.Select aria-label="Third party check" ref={thirdPartyCheckRef} >
                                            <option>Select</option>
                                            <option value="1">Intra-Group (GHO)</option>
                                            <option value="2">Intra-Group (GS)</option>
                                            <option value="3">Third Party</option>
                                        </Form.Select>
                                    </Form.Group>
                                </Col>
                            </Row>


                        </Col></Row>
                    <hr/>
                    <Row className="mt-2"><Col sm={5}>
                        <h5>Address</h5>
                    </Col>
                        <Col sm={7}>
                            <Row>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Country</Form.Label>
                                        <CountryListComponent ref={countryRef} />
                                    </Form.Group>

                                </Col>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Street</Form.Label>
                                        <Form.Control type="text" placeholder="Street" ref={streetRef}/>
                                    </Form.Group>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>City</Form.Label>
                                        <Form.Control type="text" placeholder="City" ref={cityRef}/>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Zip Code</Form.Label>
                                        <Form.Control type="text" placeholder="Zip Code" ref={zipcodeRef}/>
                                    </Form.Group>
                                </Col>
                            </Row>


                        </Col></Row>
                    <hr/>
                    <Button variant="primary" style={{float: "right"}} type="button" onClick={() => createProvider()}>
                        Submit
                    </Button>
                    <Button href="/provider" variant="danger" style={{float:"right", marginRight:"15px"}} type="button">
                        Cancel
                    </Button>
                </Form>
            </Card.Body>
        </Card>
    )
}

export default ProviderCreation
